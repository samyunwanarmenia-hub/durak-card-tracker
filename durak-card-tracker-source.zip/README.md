# Трекер карт для игры "Дурак онлайн"

Мобильное приложение для отслеживания сыгранных карт в игре "Дурак онлайн". Позволяет вручную отмечать карты, которые уже были сыграны или находятся у вас в руке, и показывает теоретически оставшиеся карты у соперников.

## Описание

Приложение представляет собой "умный блокнот" для игры в дурака с укороченной колодой из 24 карт. Вы вручную отмечаете карты по мере игры, а приложение вычисляет, какие карты теоретически остались у ваших соперников.

**Важно**: Это легальный инструмент для ведения записей, не является читом и не вмешивается в игровой процесс.

## Технологии

- **Frontend**: React + TypeScript
- **Сборщик**: Vite
- **Mobile**: Capacitor (iOS приоритет, Android опционально)
- **Хранилище**: Capacitor Preferences API (локальное сохранение)

## Структура проекта

```
softconstruckt/
├── .github/workflows/ios-build.yml    # GitHub Actions workflow для сборки iOS
├── src/
│   ├── main.tsx                       # Точка входа приложения
│   ├── App.tsx                        # Главный компонент
│   ├── components/
│   │   ├── CardList.tsx              # Список всех карт с кнопками
│   │   ├── RemainingCards.tsx        # Отображение оставшихся карт
│   │   └── NewGameButton.tsx         # Кнопка сброса игры
│   ├── lib/
│   │   ├── deck.ts                   # Логика колоды (24 карты)
│   │   └── storage.ts                # Сохранение/загрузка состояния
│   └── types.ts                       # TypeScript типы
├── capacitor.config.ts                # Конфигурация Capacitor
├── vite.config.ts                     # Конфигурация Vite
└── package.json                       # Зависимости проекта
```

## Локальная разработка

### Требования

- Node.js 20 или выше
- npm или yarn
- Для iOS разработки: macOS с установленным Xcode

### Установка

1. Клонируйте репозиторий:
```bash
git clone <repository-url>
cd softconstruckt
```

2. Установите зависимости:
```bash
npm install
```

3. Запустите dev-сервер:
```bash
npm run dev
```

Приложение будет доступно по адресу `http://localhost:5173`

### Сборка для веба

```bash
npm run build
```

Собранные файлы будут в директории `dist/`

## Настройка Capacitor для iOS

### На macOS

1. Соберите веб-версию:
```bash
npm run build
```

2. Добавьте iOS платформу:
```bash
npx cap add ios
```

3. Синхронизируйте проект:
```bash
npx cap sync ios
```

4. Откройте проект в Xcode:
```bash
npx cap open ios
```

5. В Xcode:
   - Выберите ваш Team в настройках проекта
   - Настройте Bundle Identifier
   - Выберите устройство или симулятор
   - Нажмите Run (▶️) для запуска

### Настройка Bundle Identifier

В Xcode откройте проект `ios/App/App.xcworkspace` и:

1. Выберите проект `App` в навигаторе
2. Выберите target `App`
3. Во вкладке "Signing & Capabilities":
   - Выберите ваш Apple Developer Team
   - Измените Bundle Identifier на уникальный (например: `com.yourname.durakcardtracker`)

## GitHub Actions - Автоматическая сборка iOS

Проект включает GitHub Actions workflow для автоматической сборки iOS приложения в облаке.

### Настройка секретов в GitHub

Для работы workflow необходимо добавить следующие секреты в настройках репозитория GitHub:

**Settings → Secrets and variables → Actions → New repository secret**

#### 1. IOS_CERTIFICATE_BASE64

Сертификат разработчика Apple в формате `.p12`, закодированный в base64.

**Как получить:**

1. Откройте Keychain Access на macOS
2. Найдите ваш сертификат разработчика (тип: "Apple Development" или "iOS Distribution")
3. Экспортируйте сертификат:
   - Правый клик на сертификате → Export
   - Сохраните как `.p12` файл
   - Укажите пароль при экспорте (запомните его, он понадобится для `IOS_CERTIFICATE_PASSWORD`)
4. Закодируйте в base64:
```bash
base64 -i certificate.p12 | pbcopy
```
Или на Linux:
```bash
base64 certificate.p12
```
5. Скопируйте весь вывод и добавьте как секрет `IOS_CERTIFICATE_BASE64`

#### 2. IOS_CERTIFICATE_PASSWORD

Пароль, который вы указали при экспорте `.p12` сертификата.

**Важно**: Это тот же пароль, который вы использовали при экспорте сертификата.

#### 3. IOS_PROVISIONING_PROFILE_BASE64

Provisioning Profile в формате `.mobileprovision`, закодированный в base64.

**Как получить:**

1. Войдите в [Apple Developer Portal](https://developer.apple.com/account/)
2. Перейдите в **Certificates, Identifiers & Profiles**
3. Выберите **Profiles** → **+** для создания нового профиля
4. Выберите тип профиля:
   - **Development** - для разработки и тестирования
   - **Ad Hoc** - для распространения без App Store
5. Выберите App ID (создайте новый, если нужно)
6. Выберите сертификат разработчика
7. Выберите устройства (для Ad Hoc обязательно)
8. Скачайте `.mobileprovision` файл
9. Закодируйте в base64:
```bash
base64 -i profile.mobileprovision | pbcopy
```
Или на Linux:
```bash
base64 profile.mobileprovision
```
10. Скопируйте весь вывод и добавьте как секрет `IOS_PROVISIONING_PROFILE_BASE64`

#### 4. IOS_TEAM_ID

Team ID вашего Apple Developer аккаунта.

**Как найти:**

1. Войдите в [Apple Developer Portal](https://developer.apple.com/account/)
2. В правом верхнем углу нажмите на ваше имя/компанию
3. Team ID отображается в формате: `XXXXXXXXXX` (10 символов)
4. Скопируйте и добавьте как секрет `IOS_TEAM_ID`

### Запуск сборки

1. Перейдите в **Actions** в вашем GitHub репозитории
2. Выберите workflow **iOS Build**
3. Нажмите **Run workflow**
4. Выберите тип сборки:
   - **development** - для разработки и тестирования
   - **ad-hoc** - для распространения без App Store
5. Нажмите **Run workflow**

### Получение собранного приложения

После успешной сборки:

1. Перейдите в **Actions** → выберите выполненный workflow
2. Прокрутите вниз до секции **Artifacts**
3. Скачайте артефакт `ios-app`
4. Распакуйте архив - внутри будет файл `.ipa`

### Установка .ipa файла на устройство

#### Для Development сборки:

1. Установите [Apple Configurator 2](https://apps.apple.com/app/apple-configurator-2/id1037126344) или используйте Xcode
2. Подключите iOS устройство к Mac
3. В Xcode: Window → Devices and Simulators
4. Перетащите `.ipa` файл на устройство

#### Для Ad Hoc сборки:

1. Убедитесь, что UDID вашего устройства добавлен в provisioning profile
2. Используйте [TestFlight](https://developer.apple.com/testflight/) или установите через:
   - iTunes (старые версии)
   - Apple Configurator 2
   - Сторонние инструменты (3uTools, iMazing и т.д.)

## Тестирование

Запуск тестов:
```bash
npm test
```

Запуск тестов с покрытием:
```bash
npm run test:coverage
```

## Использование приложения

1. **Отмечайте карты**: При игре отмечайте карты тремя способами:
   - **?** (Неизвестно) - карта еще не определена (по умолчанию)
   - **✓** (Сыграна) - карта была сыграна или ушла в бито
   - **👤** (Моя) - карта находится у вас в руке

2. **Отслеживайте оставшиеся карты**: В верхней части экрана отображаются карты, которые теоретически остались у соперников

3. **Новая игра**: Нажмите кнопку "Новая игра" для сброса всех отметок (требуется подтверждение)

4. **Автосохранение**: Состояние игры автоматически сохраняется при каждом изменении

## Колода карт

Приложение работает с укороченной колодой из 24 карт:

- **Масти**: Пики ♠, Червы ♥, Бубны ♦, Трефы ♣
- **Достоинства**: 9, 10, Валет (J), Дама (Q), Король (K), Туз (A)

## Скрипты

- `npm run dev` - Запуск dev-сервера
- `npm run build` - Сборка для production
- `npm run preview` - Предпросмотр production сборки
- `npm test` - Запуск тестов
- `npm run test:coverage` - Запуск тестов с покрытием
- `npm run cap:sync` - Синхронизация Capacitor
- `npm run cap:ios` - Открыть iOS проект в Xcode

## Лицензия

MIT

## Поддержка

При возникновении проблем создайте issue в репозитории.
